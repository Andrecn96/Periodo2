import { useState } from 'react'
import CryptoJS from 'crypto-js'
import './App.css'

const llave = '12345678'

const cifrar = (texto) => {
  var textoCifrado = CryptoJS.AES.encrypt(texto, llave).toString()
  return textoCifrado
}

const descifrar = (texto) => {
  var bytes = CryptoJS.AES.decrypt(texto, llave)
  var textoDescifrado = bytes.toString(CryptoJS.enc.Utf8)
  return textoDescifrado
}

function App() {
  const [texto, setTexto] = useState('')
  const [textoCifrado, setTextoCifrado] = useState('')
  const [textoOriginal, setTextoOriginal] = useState('')

  const handleCifrar = () => {
    setTextoCifrado(cifrar(texto))
    setTextoOriginal('')
  }

  const handleDescifrar = () => {
    setTextoOriginal(descifrar(textoCifrado))
  }

  return (
    <div className="App">
      <h1>Lab 4 Cipher and Decipher</h1>

      <form onSubmit={(e) => e.preventDefault()}>
        <label htmlFor="texto">Texto plano</label>
        <input
          id="texto"
          type="text"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder="Escribe un texto"
        />

        <button type="button" onClick={handleCifrar} disabled={!texto}>
          Cifrar
        </button>
        <p className="resultado">Texto Cifrado: {textoCifrado}</p>

        <button type="button" onClick={handleDescifrar} disabled={!textoCifrado}>
          Descifrar
        </button>
        <p className="resultado">Texto Descifrado: {textoOriginal}</p>
      </form>
    </div>
  )
}

export default App
