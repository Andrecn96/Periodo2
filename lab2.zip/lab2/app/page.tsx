'use client'
import { useEffect, useState } from 'react'
import { addDoc, collection, getDocs, deleteDoc, doc, updateDoc } from "firebase/firestore";
import { db } from './../firebase/firebase.config';

type Empleado = {
  id: string;
  nombre: string;
  puesto: string;
  departamento: string;
  email: string;
  salario: number;
}

const obtenerEmpleados = async () => {
  const snapshot = await getDocs(collection(db, 'empleados'))
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Empleado))
}

export default function Home() {
  const [nombre, setNombre] = useState('');
  const [puesto, setPuesto] = useState('');
  const [departamento, setDepartamento] = useState('');
  const [email, setEmail] = useState('');
  const [salario, setSalario] = useState('');
  const [items, setItems] = useState<Empleado[]>([]);

  const fetchItems = () =>
    obtenerEmpleados()
      .then(setItems)
      .catch((e) => console.error("Error al consultar empleados: ", e));

  useEffect(() => {
    fetchItems()
  }, [])

  const handleAdd = async () => {
    if (!nombre.trim()) {
      alert("Escribe al menos el nombre del empleado");
      return;
    }
    try {
      await addDoc(collection(db, 'empleados'), {
        nombre, puesto, departamento, email, salario: Number(salario) || 0
      })
    } catch (e) {
      console.error("Error al agregar empleado: ", e);
      alert("No se pudo guardar en Firebase. Revisa el archivo .env.local");
      return;
    }
    setNombre('');
    setPuesto('');
    setDepartamento('');
    setEmail('');
    setSalario('');
    fetchItems();
  }

  const handleDelete = async (id: string) => {
    if (!id) return;
    await deleteDoc(doc(db, 'empleados', id));
    fetchItems();
  }

  const handleEdit = async (item: Empleado) => {
    const editNombre = prompt("Nombre", item.nombre);
    if (editNombre === null) return;
    const editPuesto = prompt("Puesto", item.puesto);
    if (editPuesto === null) return;
    const editDepartamento = prompt("Departamento", item.departamento);
    if (editDepartamento === null) return;
    const editEmail = prompt("Email", item.email);
    if (editEmail === null) return;
    const editSalario = prompt("Salario", String(item.salario));
    if (editSalario === null) return;

    await updateDoc(doc(db, 'empleados', item.id), {
      nombre: editNombre,
      puesto: editPuesto,
      departamento: editDepartamento,
      email: editEmail,
      salario: Number(editSalario) || 0,
    })
    fetchItems();
  }

  return (
    <div className="font-sans grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20" >
      <h1>NextJS Firebase - Empleados</h1>

      <div className="flex flex-col items-center gap-2">
        <input type="text" className="border-2" placeholder="Nombre" value={nombre} onChange={(e) =>
          setNombre(e.target.value)} />
        <input type="text" className="border-2" placeholder="Puesto" value={puesto} onChange={(e) =>
          setPuesto(e.target.value)} />
        <input type="text" className="border-2" placeholder="Departamento" value={departamento} onChange={(e) =>
          setDepartamento(e.target.value)} />
        <input type="email" className="border-2" placeholder="Email" value={email} onChange={(e) =>
          setEmail(e.target.value)} />
        <input type="number" className="border-2" placeholder="Salario" value={salario} onChange={(e) =>
          setSalario(e.target.value)} />
        <button className="border p-2" onClick={(handleAdd)}>Agregar</button>

        <ul>
          {items.map((item) => <li key={item.id}>
            {item.nombre} - {item.puesto} - {item.departamento} - {item.email} - ${item.salario}
            <button className="p-2 border bg-yellow-500 text-white cursor-pointer"
              onClick={() => { handleEdit(item) }}>Edit</button>
            <button className="p-2 border bg-red-500 text-white cursor-pointer"
              onClick={() => { handleDelete(item.id) }}>Delete</button>
          </li>)}
        </ul>
      </div>
    </div>
  );
}
