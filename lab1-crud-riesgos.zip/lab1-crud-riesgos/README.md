# Tabla de Auditoría y Riesgos — CRUD (Lab1)

Aplicación web de **CRUD** construida con **React 18**, **TypeScript** y **TailwindCSS**, para el registro,
seguimiento y gestión de una **Tabla de Auditoría / Registro de Riesgos**. El proyecto sigue los principios
de **Clean Architecture** vistos en la Semana 1 (Tec de Monterrey, TC3005B): separación en capas de
Dominio, Aplicación, Datos e Infraestructura, con la Regla de Dependencia apuntando siempre hacia adentro.

## Estructura del proyecto

```
lab1-crud-riesgos/
├── src/
│   ├── domain/                     # Capa de Dominio (reglas de negocio, no depende de nada externo)
│   │   ├── entities/
│   │   │   └── Risk.ts             # Entidad Risk + tipos (categoría, nivel, estado) + cálculo de nivel
│   │   ├── repositories/
│   │   │   └── RiskRepository.ts   # Interfaz del repositorio (Dependency Inversion)
│   │   └── useCases/               # Casos de uso (lógica de aplicación)
│   │       ├── GetRisksUseCase.ts
│   │       ├── AddRiskUseCase.ts
│   │       ├── UpdateRiskUseCase.ts
│   │       └── DeleteRiskUseCase.ts
│   │
│   ├── data/                       # Capa de Datos (implementa las interfaces del dominio)
│   │   ├── repositories/
│   │   │   └── RiskRepositoryImpl.ts  # Implementación concreta de RiskRepository
│   │   └── sources/
│   │       └── RiskLocalDataSource.ts # Fuente de datos (lee/escribe en localStorage)
│   │
│   ├── infrastructure/             # Capa de Infraestructura (detalles técnicos externos)
│   │   └── storage/
│   │       └── LocalStorageClient.ts  # Wrapper sobre window.localStorage
│   │
│   ├── presentation/                # Capa de Presentación (UI y adaptadores)
│   │   ├── components/
│   │   │   ├── RiskForm.tsx         # Formulario de alta / edición de riesgos
│   │   │   ├── RiskTable.tsx        # Tabla con listado, edición y eliminación
│   │   │   └── RiskLevelBadge.tsx   # Badge visual del nivel de riesgo calculado
│   │   ├── hooks/
│   │   │   └── useRisks.ts          # Hook que conecta los casos de uso con la UI (patrón adaptador)
│   │   └── pages/
│   │       └── RisksPage.tsx        # Página principal que orquesta formulario + tabla
│   │
│   ├── App.tsx                      # Punto de entrada de la app (renderiza RisksPage)
│   ├── main.tsx                     # Bootstrap de React
│   └── index.css                    # Estilos globales + import de TailwindCSS
│
├── index.html
├── package.json
├── tsconfig*.json
├── vite.config.ts
└── postcss.config.js
```

### Regla de dependencia

`presentation` → `domain` ← `data` → `infrastructure`

Las capas internas (`domain`) no conocen ni dependen de `data`, `infrastructure` ni `presentation`.
`data` implementa las interfaces (`RiskRepository`) definidas en `domain`, y `presentation` consume los
casos de uso de `domain` a través del hook `useRisks`, sin conocer los detalles de persistencia.

## Funcionalidades esperadas

La aplicación implementa un **CRUD completo** sobre la entidad `Risk` (riesgo de auditoría):

| Operación | Descripción |
|-----------|-------------|
| **Create** | Alta de un nuevo riesgo mediante el formulario (nombre, descripción, categoría, probabilidad, impacto, responsable, estado, acciones de mitigación, fecha). |
| **Read**   | Listado de todos los riesgos registrados en una tabla, con el nivel de riesgo calculado automáticamente (Bajo / Medio / Alto / Crítico) a partir de `probabilidad × impacto`. |
| **Update** | Edición de un riesgo existente reutilizando el mismo formulario (botón "Editar" en cada fila). |
| **Delete** | Eliminación de un riesgo con confirmación previa (botón "Eliminar" en cada fila). |

Funcionalidades adicionales:

- **Persistencia local**: los datos se guardan en `localStorage` a través de la capa de infraestructura,
  por lo que la información sobrevive a recargas del navegador.
- **Validación básica**: el nombre del riesgo es obligatorio (validado en el caso de uso, no solo en la UI).
- **Cálculo automático de nivel de riesgo**: función pura `calcularNivelRiesgo` en la capa de dominio.
- **Diseño responsivo** con TailwindCSS.

## Entidad principal: `Risk`

```ts
interface Risk {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: 'Operacional' | 'Financiero' | 'Legal' | 'Tecnológico' | 'Reputacional';
  probabilidad: number; // 1 (baja) - 5 (alta)
  impacto: number;      // 1 (bajo) - 5 (alto)
  responsable: string;
  estado: 'Abierto' | 'En mitigación' | 'Cerrado';
  accionesMitigacion: string;
  fechaIdentificacion: string; // ISO date
}
```

## Stack técnico

- **React 18** + **TypeScript**
- **Vite** como bundler / dev server
- **TailwindCSS 4** para estilos
- **localStorage** como fuente de datos (capa de infraestructura, reemplazable por una API REST sin tocar
  `domain` ni `presentation`, gracias a la inversión de dependencias)

## Instalación y uso

```bash
git clone <url-del-repositorio>
cd lab1-crud-riesgos
npm install
npm run dev
```

Abre [http://localhost:5173](http://localhost:5173) en tu navegador para ver el resultado.

### Build de producción

```bash
npm run build
```

## Referencias

- Patrón Clean Architecture (Robert C. Martin / "Uncle Bob")
- Material de clase: *TC3005B WEB — Desarrollo e implantación de sistemas de software, Semana 1: Patrones*
