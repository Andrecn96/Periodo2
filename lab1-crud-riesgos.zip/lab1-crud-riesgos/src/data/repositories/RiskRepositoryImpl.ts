import type { RiskRepository } from '../../domain/repositories/RiskRepository';
import type { NewRisk, Risk } from '../../domain/entities/Risk';
import { RiskLocalDataSource } from '../sources/RiskLocalDataSource';

export class RiskRepositoryImpl implements RiskRepository {
  private readonly dataSource: RiskLocalDataSource;

  constructor(dataSource: RiskLocalDataSource = new RiskLocalDataSource()) {
    this.dataSource = dataSource;
  }

  async getAll(): Promise<Risk[]> {
    return this.dataSource.read();
  }

  async getById(id: string): Promise<Risk | undefined> {
    return this.dataSource.read().find((risk) => risk.id === id);
  }

  async create(risk: NewRisk): Promise<Risk> {
    const risks = this.dataSource.read();
    const newRisk: Risk = { ...risk, id: crypto.randomUUID() };
    this.dataSource.write([...risks, newRisk]);
    return newRisk;
  }

  async update(id: string, risk: NewRisk): Promise<Risk> {
    const risks = this.dataSource.read();
    const updated: Risk = { ...risk, id };
    const next = risks.map((r) => (r.id === id ? updated : r));
    this.dataSource.write(next);
    return updated;
  }

  async remove(id: string): Promise<void> {
    const risks = this.dataSource.read();
    this.dataSource.write(risks.filter((r) => r.id !== id));
  }
}
