import { LocalStorageClient } from '../../infrastructure/storage/LocalStorageClient';
import type { Risk } from '../../domain/entities/Risk';

const STORAGE_KEY = 'lab1-riesgos';

export class RiskLocalDataSource {
  private readonly storage: LocalStorageClient;

  constructor(storage: LocalStorageClient = new LocalStorageClient()) {
    this.storage = storage;
  }

  read(): Risk[] {
    return this.storage.get<Risk[]>(STORAGE_KEY) ?? [];
  }

  write(risks: Risk[]): void {
    this.storage.set(STORAGE_KEY, risks);
  }
}
