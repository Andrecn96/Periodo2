import { RisksPage } from './presentation/pages/RisksPage';

function App() {
  return <RisksPage />;
}

export default App;
