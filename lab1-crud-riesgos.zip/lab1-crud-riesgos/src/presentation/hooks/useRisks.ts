import { useCallback, useEffect, useMemo, useState } from 'react';
import type { NewRisk, Risk } from '../../domain/entities/Risk';
import { RiskRepositoryImpl } from '../../data/repositories/RiskRepositoryImpl';
import { GetRisksUseCase } from '../../domain/useCases/GetRisksUseCase';
import { AddRiskUseCase } from '../../domain/useCases/AddRiskUseCase';
import { UpdateRiskUseCase } from '../../domain/useCases/UpdateRiskUseCase';
import { DeleteRiskUseCase } from '../../domain/useCases/DeleteRiskUseCase';

export function useRisks() {
  const repository = useMemo(() => new RiskRepositoryImpl(), []);
  const getRisksUseCase = useMemo(() => new GetRisksUseCase(repository), [repository]);
  const addRiskUseCase = useMemo(() => new AddRiskUseCase(repository), [repository]);
  const updateRiskUseCase = useMemo(() => new UpdateRiskUseCase(repository), [repository]);
  const deleteRiskUseCase = useMemo(() => new DeleteRiskUseCase(repository), [repository]);

  const [risks, setRisks] = useState<Risk[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getRisksUseCase.execute();
      setRisks(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al cargar los riesgos.');
    } finally {
      setLoading(false);
    }
  }, [getRisksUseCase]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const addRisk = useCallback(
    async (risk: NewRisk) => {
      await addRiskUseCase.execute(risk);
      await refresh();
    },
    [addRiskUseCase, refresh],
  );

  const updateRisk = useCallback(
    async (id: string, risk: NewRisk) => {
      await updateRiskUseCase.execute(id, risk);
      await refresh();
    },
    [updateRiskUseCase, refresh],
  );

  const deleteRisk = useCallback(
    async (id: string) => {
      await deleteRiskUseCase.execute(id);
      await refresh();
    },
    [deleteRiskUseCase, refresh],
  );

  return { risks, loading, error, addRisk, updateRisk, deleteRisk, refresh };
}
