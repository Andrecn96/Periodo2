import { useState } from 'react';
import { useRisks } from '../hooks/useRisks';
import { RiskForm } from '../components/RiskForm';
import { RiskTable } from '../components/RiskTable';
import type { Risk } from '../../domain/entities/Risk';

export function RisksPage() {
  const { risks, loading, error, addRisk, updateRisk, deleteRisk } = useRisks();
  const [riskToEdit, setRiskToEdit] = useState<Risk | null>(null);

  const handleSubmit = async (risk: Parameters<typeof addRisk>[0]) => {
    if (riskToEdit) {
      await updateRisk(riskToEdit.id, risk);
      setRiskToEdit(null);
    } else {
      await addRisk(risk);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('¿Eliminar este riesgo de la tabla de auditoría?')) {
      await deleteRisk(id);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-slate-900 text-white py-6 px-6">
        <h1 className="text-2xl font-bold">Tabla de Auditoría y Riesgos</h1>
        <p className="text-slate-300 text-sm mt-1">
          CRUD para el registro y seguimiento de riesgos identificados en auditoría.
        </p>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 space-y-8">
        <RiskForm
          riskToEdit={riskToEdit}
          onSubmit={handleSubmit}
          onCancel={() => setRiskToEdit(null)}
        />

        {error && <p className="text-red-600 text-sm">{error}</p>}
        {loading ? (
          <p className="text-slate-500">Cargando riesgos...</p>
        ) : (
          <RiskTable risks={risks} onEdit={setRiskToEdit} onDelete={handleDelete} />
        )}
      </main>
    </div>
  );
}
