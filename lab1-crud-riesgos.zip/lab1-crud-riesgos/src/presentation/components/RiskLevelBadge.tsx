import { calcularNivelRiesgo } from '../../domain/entities/Risk';

const styles: Record<string, string> = {
  Bajo: 'bg-green-100 text-green-800',
  Medio: 'bg-yellow-100 text-yellow-800',
  Alto: 'bg-orange-100 text-orange-800',
  Crítico: 'bg-red-100 text-red-800',
};

export function RiskLevelBadge({ probabilidad, impacto }: { probabilidad: number; impacto: number }) {
  const nivel = calcularNivelRiesgo(probabilidad, impacto);
  return (
    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${styles[nivel]}`}>
      {nivel} ({probabilidad * impacto})
    </span>
  );
}
