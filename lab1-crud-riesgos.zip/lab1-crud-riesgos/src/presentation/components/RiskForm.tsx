import { useEffect, useState } from 'react';
import type { NewRisk, Risk, RiskCategory, RiskStatus } from '../../domain/entities/Risk';

const CATEGORIAS: RiskCategory[] = ['Operacional', 'Financiero', 'Legal', 'Tecnológico', 'Reputacional'];
const ESTADOS: RiskStatus[] = ['Abierto', 'En mitigación', 'Cerrado'];

const EMPTY_FORM: NewRisk = {
  nombre: '',
  descripcion: '',
  categoria: 'Operacional',
  probabilidad: 1,
  impacto: 1,
  responsable: '',
  estado: 'Abierto',
  accionesMitigacion: '',
  fechaIdentificacion: new Date().toISOString().slice(0, 10),
};

interface RiskFormProps {
  riskToEdit: Risk | null;
  onSubmit: (risk: NewRisk) => Promise<void>;
  onCancel: () => void;
}

export function RiskForm({ riskToEdit, onSubmit, onCancel }: RiskFormProps) {
  const [form, setForm] = useState<NewRisk>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (riskToEdit) {
      const { id, ...rest } = riskToEdit;
      setForm(rest);
    } else {
      setForm(EMPTY_FORM);
    }
  }, [riskToEdit]);

  const handleChange = <K extends keyof NewRisk>(key: K, value: NewRisk[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await onSubmit(form);
      setForm(EMPTY_FORM);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al guardar el riesgo.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6 space-y-4">
      <h2 className="text-lg font-semibold text-slate-800">
        {riskToEdit ? 'Editar riesgo' : 'Nuevo riesgo'}
      </h2>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Nombre del riesgo</label>
          <input
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.nombre}
            onChange={(e) => handleChange('nombre', e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Responsable</label>
          <input
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.responsable}
            onChange={(e) => handleChange('responsable', e.target.value)}
            required
          />
        </div>

        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-slate-600 mb-1">Descripción</label>
          <textarea
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            rows={2}
            value={form.descripcion}
            onChange={(e) => handleChange('descripcion', e.target.value)}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Categoría</label>
          <select
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.categoria}
            onChange={(e) => handleChange('categoria', e.target.value as RiskCategory)}
          >
            {CATEGORIAS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Estado</label>
          <select
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.estado}
            onChange={(e) => handleChange('estado', e.target.value as RiskStatus)}
          >
            {ESTADOS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">
            Probabilidad (1-5)
          </label>
          <input
            type="number"
            min={1}
            max={5}
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.probabilidad}
            onChange={(e) => handleChange('probabilidad', Number(e.target.value))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Impacto (1-5)</label>
          <input
            type="number"
            min={1}
            max={5}
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.impacto}
            onChange={(e) => handleChange('impacto', Number(e.target.value))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">
            Fecha de identificación
          </label>
          <input
            type="date"
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            value={form.fechaIdentificacion}
            onChange={(e) => handleChange('fechaIdentificacion', e.target.value)}
          />
        </div>

        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-slate-600 mb-1">
            Acciones de mitigación
          </label>
          <textarea
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            rows={2}
            value={form.accionesMitigacion}
            onChange={(e) => handleChange('accionesMitigacion', e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-2">
        {riskToEdit && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm rounded border border-slate-300 text-slate-600 hover:bg-slate-50"
          >
            Cancelar
          </button>
        )}
        <button
          type="submit"
          disabled={submitting}
          className="px-4 py-2 text-sm rounded bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {riskToEdit ? 'Guardar cambios' : 'Agregar riesgo'}
        </button>
      </div>
    </form>
  );
}
