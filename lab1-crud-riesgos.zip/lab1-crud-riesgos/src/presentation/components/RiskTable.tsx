import type { Risk } from '../../domain/entities/Risk';
import { RiskLevelBadge } from './RiskLevelBadge';

interface RiskTableProps {
  risks: Risk[];
  onEdit: (risk: Risk) => void;
  onDelete: (id: string) => void;
}

export function RiskTable({ risks, onEdit, onDelete }: RiskTableProps) {
  if (risks.length === 0) {
    return (
      <p className="text-center text-slate-500 py-10">
        No hay riesgos registrados todavía. Agrega el primero usando el formulario.
      </p>
    );
  }

  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
          <tr>
            <th className="px-4 py-3 text-left">Riesgo</th>
            <th className="px-4 py-3 text-left">Categoría</th>
            <th className="px-4 py-3 text-left">Nivel</th>
            <th className="px-4 py-3 text-left">Responsable</th>
            <th className="px-4 py-3 text-left">Estado</th>
            <th className="px-4 py-3 text-left">Fecha</th>
            <th className="px-4 py-3 text-right">Acciones</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {risks.map((risk) => (
            <tr key={risk.id} className="hover:bg-slate-50">
              <td className="px-4 py-3">
                <div className="font-medium text-slate-800">{risk.nombre}</div>
                <div className="text-slate-500 text-xs">{risk.descripcion}</div>
              </td>
              <td className="px-4 py-3">{risk.categoria}</td>
              <td className="px-4 py-3">
                <RiskLevelBadge probabilidad={risk.probabilidad} impacto={risk.impacto} />
              </td>
              <td className="px-4 py-3">{risk.responsable}</td>
              <td className="px-4 py-3">{risk.estado}</td>
              <td className="px-4 py-3">{risk.fechaIdentificacion}</td>
              <td className="px-4 py-3 text-right space-x-2">
                <button
                  onClick={() => onEdit(risk)}
                  className="text-indigo-600 hover:underline text-xs font-medium"
                >
                  Editar
                </button>
                <button
                  onClick={() => onDelete(risk.id)}
                  className="text-red-600 hover:underline text-xs font-medium"
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
