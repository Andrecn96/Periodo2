import type { RiskRepository } from '../repositories/RiskRepository';
import type { NewRisk, Risk } from '../entities/Risk';

export class UpdateRiskUseCase {
  private readonly riskRepository: RiskRepository;

  constructor(riskRepository: RiskRepository) {
    this.riskRepository = riskRepository;
  }

  execute(id: string, risk: NewRisk): Promise<Risk> {
    if (!risk.nombre.trim()) {
      throw new Error('El nombre del riesgo es obligatorio.');
    }
    return this.riskRepository.update(id, risk);
  }
}
