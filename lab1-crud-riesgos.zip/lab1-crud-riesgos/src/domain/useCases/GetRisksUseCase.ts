import type { RiskRepository } from '../repositories/RiskRepository';
import type { Risk } from '../entities/Risk';

export class GetRisksUseCase {
  private readonly riskRepository: RiskRepository;

  constructor(riskRepository: RiskRepository) {
    this.riskRepository = riskRepository;
  }

  execute(): Promise<Risk[]> {
    return this.riskRepository.getAll();
  }
}
