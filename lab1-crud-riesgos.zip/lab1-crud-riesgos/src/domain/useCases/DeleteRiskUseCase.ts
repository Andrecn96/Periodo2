import type { RiskRepository } from '../repositories/RiskRepository';

export class DeleteRiskUseCase {
  private readonly riskRepository: RiskRepository;

  constructor(riskRepository: RiskRepository) {
    this.riskRepository = riskRepository;
  }

  execute(id: string): Promise<void> {
    return this.riskRepository.remove(id);
  }
}
