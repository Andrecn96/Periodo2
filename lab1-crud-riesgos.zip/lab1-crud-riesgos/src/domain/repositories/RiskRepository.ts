import type { NewRisk, Risk } from '../entities/Risk';

export interface RiskRepository {
  getAll(): Promise<Risk[]>;
  getById(id: string): Promise<Risk | undefined>;
  create(risk: NewRisk): Promise<Risk>;
  update(id: string, risk: NewRisk): Promise<Risk>;
  remove(id: string): Promise<void>;
}
