export type RiskCategory =
  | 'Operacional'
  | 'Financiero'
  | 'Legal'
  | 'Tecnológico'
  | 'Reputacional';

export type RiskLevel = 'Bajo' | 'Medio' | 'Alto' | 'Crítico';

export type RiskStatus = 'Abierto' | 'En mitigación' | 'Cerrado';

export interface Risk {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: RiskCategory;
  probabilidad: number; // 1 (baja) - 5 (alta)
  impacto: number; // 1 (bajo) - 5 (alto)
  responsable: string;
  estado: RiskStatus;
  accionesMitigacion: string;
  fechaIdentificacion: string; // ISO date
}

export type NewRisk = Omit<Risk, 'id'>;

export function calcularNivelRiesgo(probabilidad: number, impacto: number): RiskLevel {
  const score = probabilidad * impacto;
  if (score <= 4) return 'Bajo';
  if (score <= 9) return 'Medio';
  if (score <= 16) return 'Alto';
  return 'Crítico';
}
