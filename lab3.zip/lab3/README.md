# Lab 3 — Lista de tareas

Lista de pendientes hecha con React + Vite y Supabase como base de datos.

## Cómo correrlo

1. Crea la tabla en Supabase: copia `supabase/pendientes.sql` en el SQL Editor y ejecútalo.
2. Copia `.env.example` a `.env` y llena `VITE_SUPABASE_URL` y `VITE_SUPABASE_KEY` con los datos de tu proyecto.
3. Instala y levanta el proyecto:

```bash
npm install
npm run dev
```

## Estructura

- `src/supabase-client.js` — conexión a Supabase.
- `src/App.jsx` — interfaz y operaciones sobre la tabla `pendientes` (consultar, agregar, completar, borrar).
