import { useEffect, useState } from "react";
import "./App.css";
import supabase from "./supabase-client";

function App() {
  const [todoList, setTodoList] = useState([]);
  const [newTodo, setNewTodo] = useState("");
  const [cargando, setCargando] = useState(true);
  const [aviso, setAviso] = useState("");

  const consulta = async () => {
    const { data, error } = await supabase
      .from("pendientes")
      .select("*")
      .order("created_at", { ascending: true });
    if (error) {
      console.log("Error de conexion en consulta: ", error);
      setAviso("No se pudieron cargar las tareas.");
    } else {
      setTodoList(data);
      setAviso("");
    }
    setCargando(false);
  };

  useEffect(() => {
    consulta();
  }, []);

  const addTodo = async (e) => {
    e.preventDefault();
    const name = newTodo.trim();
    if (!name) return;

    const { data, error } = await supabase
      .from("pendientes")
      .insert([{ name, isCompleted: false }])
      .select();

    if (error) {
      console.log("Error en el insert: ", error);
      setAviso("No se pudo agregar la tarea.");
    } else {
      setTodoList((prev) => [...prev, data[0]]);
      setNewTodo("");
      setAviso("");
    }
  };

  const completeTask = async (id, isCompleted) => {
    const { error } = await supabase
      .from("pendientes")
      .update({ isCompleted: !isCompleted })
      .eq("id", id);

    if (error) {
      console.log("error en el update task: ", error);
      setAviso("No se pudo actualizar la tarea.");
    } else {
      setTodoList((prev) =>
        prev.map((todo) => (todo.id === id ? { ...todo, isCompleted: !isCompleted } : todo))
      );
      setAviso("");
    }
  };

  const deleteTask = async (id) => {
    const { error } = await supabase.from("pendientes").delete().eq("id", id);

    if (error) {
      console.log("error deleting task: ", error);
      setAviso("No se pudo borrar la tarea.");
    } else {
      setTodoList((prev) => prev.filter((todo) => todo.id !== id));
      setAviso("");
    }
  };

  return (
    <div className="contenedor">
      <h1>Lista de tareas</h1>

      <form onSubmit={addTodo}>
        <input
          type="text"
          placeholder="Escribe una tarea"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
        />
        <button type="submit">Agregar</button>
      </form>

      {aviso && <p className="aviso">{aviso}</p>}

      {cargando ? (
        <p>Cargando...</p>
      ) : todoList.length === 0 ? (
        <p>No hay tareas.</p>
      ) : (
        <ul>
          {todoList.map((todo) => (
            <li key={todo.id}>
              <input
                type="checkbox"
                checked={todo.isCompleted}
                onChange={() => completeTask(todo.id, todo.isCompleted)}
              />
              <span className={todo.isCompleted ? "completada" : ""}>{todo.name}</span>
              <button onClick={() => deleteTask(todo.id)}>Eliminar</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;
