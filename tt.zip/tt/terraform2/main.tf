resource "random_pet" "nombre" {
  length = 2
}

resource "local_file" "equipo" {
  for_each = toset(["front", "back"])
  filename = "${path.module}/${each.key}.txt"
  content  = random_pet.nombre.id
}

output "archivos" {
  value = keys(local_file.equipo)
}
