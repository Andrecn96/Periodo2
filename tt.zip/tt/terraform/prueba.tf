hcl
variable "mensaje" {
  default = "Hola TEC"
}

resource "local_file" "saludo" {
  filename = "${path.module}/saludo.txt"
  content  = var.mensaje
}

output "ruta" {
  value = local_file.saludo.filename
}